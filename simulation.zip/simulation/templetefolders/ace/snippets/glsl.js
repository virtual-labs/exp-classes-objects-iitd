define("ace/snippets/glsl",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="glsl"});                (function() {
                    window.require(["ace/snippets/glsl"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            